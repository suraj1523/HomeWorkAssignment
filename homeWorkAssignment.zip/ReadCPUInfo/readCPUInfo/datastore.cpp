//Homework Assignment :
//Author : Suraj Kumar Sanga
//Date : 20.07.2017

#include "datastore.h"
#include <QFile>
#include <QTextStream>

dataStore::dataStore(QObject *parent) : QObject(parent)
{

    readData();
}

//Method to read and store the data in the Array of QString
void dataStore::readData(){

    //reading file from its fixed path defined in datastore.h
    QFile file(QString(FilePath));

    if (!file.open(QIODevice::ReadOnly)) {
        qDebug("Unable to open file %s, aborting\n",
               qPrintable(file.fileName()));
        qDebug("File Opened Successfully");
    }

    if (!file.isReadable()) {
        qDebug("Unable to read file %s, aborting\n",
               qPrintable(file.fileName()));
    }

    //storing the contents of the file in the Qbytearray
    QByteArray contents = file.readAll();
    QTextStream in(&contents);

    //reading each line and storing the array of QStrings
    while (!in.atEnd()) {
        QString line = in.readLine();
        DataLine[Length] = line;
        Length++;
    }

    file.close();

    qDebug("Data from the file stored in the QString array");

}

QString dataStore::sendLineInfo()
{

    if (Count < Length) {
        emit sendLineData(DataLine[Count]);
        Count++;
        return DataLine[Count];
    }

    else{
        qDebug("Reached End of FILE: %s\n", qPrintable(DataLine[Count]));
        emit sendLineData("End of File");
        return "End of File";
    }

}

