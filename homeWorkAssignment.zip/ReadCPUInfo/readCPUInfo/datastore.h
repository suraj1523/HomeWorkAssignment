#ifndef DATASTORE_H
#define DATASTORE_H

#include <QObject>

//file path
#define FilePath "/proc/cpuinfo"
//assuming the maximum file length of 500
#define maxFileLength 500

class dataStore : public QObject
{
    Q_OBJECT
public:
    dataStore(QObject *parent = 0);


signals:
    void sendLineData(QString Info);

public slots:
    void readData();
    QString sendLineInfo();

private:
    int Count =0;
    int Length = 0;
    QString lineInfo;
    QString DataLine[maxFileLength];

};

#endif // DATASTORE_H
