//Homework Assignment :
//Author : Suraj Kumar Sanga
//Date : 20.07.2017

#include <QGuiApplication>
#include <QQmlApplicationEngine>


//To add the QML Context property
#include <QQmlContext>

#include "datastore.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    //To load the QML application
    QQmlApplicationEngine engine;

    QQmlContext* context = engine.rootContext();

    //creating object of the class
    dataStore fileInfo;

    //setting the context of the calss for accessibility from qml !
    context->setContextProperty("dataStoreContext",&fileInfo);

    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    return app.exec();
}

